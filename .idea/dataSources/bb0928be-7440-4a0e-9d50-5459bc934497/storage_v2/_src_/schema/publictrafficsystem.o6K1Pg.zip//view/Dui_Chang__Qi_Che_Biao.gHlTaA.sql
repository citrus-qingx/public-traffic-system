create definer = root@localhost view 队长_汽车表 as
select `publictrafficsystem`.`汽车表`.`车牌号`  AS `车牌号`,
       `publictrafficsystem`.`汽车表`.`车龄`   AS `车龄`,
       `publictrafficsystem`.`汽车表`.`车型`   AS `车型`,
       `publictrafficsystem`.`汽车表`.`座位数`  AS `座位数`,
       `publictrafficsystem`.`汽车表`.`年检月份` AS `年检月份`,
       `publictrafficsystem`.`汽车表`.`线路号`  AS `线路号`
from `publictrafficsystem`.`汽车表`
where `publictrafficsystem`.`汽车表`.`线路号` in (select `publictrafficsystem`.`线路表`.`线路号`
                                            from `publictrafficsystem`.`线路表`
                                            where (`publictrafficsystem`.`线路表`.`车队号` =
                                                   (select `publictrafficsystem`.`车队表`.`车队号`
                                                    from `publictrafficsystem`.`车队表`
                                                    where (`publictrafficsystem`.`车队表`.`队长工号` = left(user(), 8)))));

