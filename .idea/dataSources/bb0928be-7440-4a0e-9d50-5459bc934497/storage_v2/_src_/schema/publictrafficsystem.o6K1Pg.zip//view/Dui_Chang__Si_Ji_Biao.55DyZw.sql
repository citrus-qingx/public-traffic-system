create definer = root@localhost view 队长_司机表 as
select `publictrafficsystem`.`司机线路表`.`工号` AS `工号`, `publictrafficsystem`.`司机线路表`.`线路号` AS `线路号`
from `publictrafficsystem`.`司机线路表`
where `publictrafficsystem`.`司机线路表`.`线路号` in (select `publictrafficsystem`.`线路表`.`线路号`
                                              from `publictrafficsystem`.`线路表`
                                              where (`publictrafficsystem`.`线路表`.`车队号` =
                                                     (select `publictrafficsystem`.`车队表`.`车队号`
                                                      from `publictrafficsystem`.`车队表`
                                                      where (`publictrafficsystem`.`车队表`.`队长工号` = left(user(), 8)))));

