create definer = root@localhost view 路队长_违章记录表 as
select `publictrafficsystem`.`违章记录表`.`违章编号`    AS `违章编号`,
       `publictrafficsystem`.`违章记录表`.`违章司机工号`  AS `违章司机工号`,
       `publictrafficsystem`.`违章记录表`.`违章汽车车牌号` AS `违章汽车车牌号`,
       `publictrafficsystem`.`违章记录表`.`违章名`     AS `违章名`,
       `publictrafficsystem`.`违章记录表`.`违章时间`    AS `违章时间`,
       `publictrafficsystem`.`违章记录表`.`违章地点`    AS `违章地点`
from `publictrafficsystem`.`违章记录表`
where `publictrafficsystem`.`违章记录表`.`违章司机工号` in (select `publictrafficsystem`.`司机线路表`.`工号`
                                                 from `publictrafficsystem`.`司机线路表`
                                                 where (`publictrafficsystem`.`司机线路表`.`线路号` =
                                                        (select `publictrafficsystem`.`线路表`.`线路号`
                                                         from `publictrafficsystem`.`线路表`
                                                         where (`publictrafficsystem`.`线路表`.`路队长工号` = left(user(), 8)))));

