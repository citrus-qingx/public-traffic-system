create definer = root@localhost view 司机_司机表 as
select `publictrafficsystem`.`司机表`.`工号`   AS `工号`,
       `publictrafficsystem`.`司机表`.`姓名`   AS `姓名`,
       `publictrafficsystem`.`司机表`.`性别`   AS `性别`,
       `publictrafficsystem`.`司机表`.`出生年份` AS `出生年份`,
       `publictrafficsystem`.`司机表`.`职位`   AS `职位`
from `publictrafficsystem`.`司机表`
where (`publictrafficsystem`.`司机表`.`工号` = left(user(), 8));

