create definer = root@localhost view 司机_违章记录表 as
select `publictrafficsystem`.`违章记录表`.`违章编号`    AS `违章编号`,
       `publictrafficsystem`.`违章记录表`.`违章司机工号`  AS `违章司机工号`,
       `publictrafficsystem`.`违章记录表`.`违章汽车车牌号` AS `违章汽车车牌号`,
       `publictrafficsystem`.`违章记录表`.`违章名`     AS `违章名`,
       `publictrafficsystem`.`违章记录表`.`违章时间`    AS `违章时间`,
       `publictrafficsystem`.`违章记录表`.`违章地点`    AS `违章地点`
from `publictrafficsystem`.`违章记录表`
where (`publictrafficsystem`.`违章记录表`.`违章司机工号` = left(user(), 8));

